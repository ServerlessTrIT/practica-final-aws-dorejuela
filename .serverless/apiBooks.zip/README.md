# ejercicioPractico
Ejercicio práctico evaluable
